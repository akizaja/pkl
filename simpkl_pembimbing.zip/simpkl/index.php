<?php
require_once 'config.php';
if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'pembimbing') {
    header('Location: dashboard.php');
} else {
    header('Location: login.php');
}
exit;
