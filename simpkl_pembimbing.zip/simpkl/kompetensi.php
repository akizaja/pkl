<?php
require_once 'config.php';
requireRole('pembimbing');
$activePage = 'kompetensi';
$pageTitle  = 'Penilaian Kompetensi';
$pid = getPembimbingId();
$pdo = getDB();
$siswaList = getSiswaBimbingan($pid);

// Daftar kompetensi default
$kompetensiList = [
  ['id'=>'K01','label'=>'Mampu menganalisis kebutuhan sistem','cat'=>'Analisis'],
  ['id'=>'K02','label'=>'Mampu membuat dokumentasi teknis','cat'=>'Dokumentasi'],
  ['id'=>'K03','label'=>'Mampu bekerja dalam tim','cat'=>'Soft Skill'],
  ['id'=>'K04','label'=>'Mampu menggunakan tools pengembangan','cat'=>'Teknis'],
  ['id'=>'K05','label'=>'Mampu melakukan debugging & troubleshooting','cat'=>'Teknis'],
  ['id'=>'K06','label'=>'Memahami konsep database relasional','cat'=>'Teknis'],
  ['id'=>'K07','label'=>'Mampu membuat laporan kerja yang baik','cat'=>'Dokumentasi'],
  ['id'=>'K08','label'=>'Memiliki inisiatif & tanggung jawab','cat'=>'Soft Skill'],
  ['id'=>'K09','label'=>'Mampu berkomunikasi dengan klien','cat'=>'Soft Skill'],
  ['id'=>'K10','label'=>'Mampu mengimplementasikan keamanan dasar','cat'=>'Teknis'],
];

// Handle simpan kompetensi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['siswa_id'])) {
    $siswa_id   = (int)$_POST['siswa_id'];
    $kompChecked = $_POST['komp'] ?? [];
    // Simpan sebagai JSON di log_aktivitas (bisa diubah ke tabel sendiri)
    $data = json_encode($kompChecked);
    // Cek tabel kompetensi_pkl dulu, fallback ke log
    try {
        $check = $pdo->prepare("SELECT id FROM kompetensi_pkl WHERE siswa_id=? AND pembimbing_id=?");
        $check->execute([$siswa_id,$pid]);
        if ($check->fetch()) {
            $pdo->prepare("UPDATE kompetensi_pkl SET data_kompetensi=?,updated_at=NOW() WHERE siswa_id=? AND pembimbing_id=?")->execute([$data,$siswa_id,$pid]);
        } else {
            $pdo->prepare("INSERT INTO kompetensi_pkl (siswa_id,pembimbing_id,data_kompetensi,updated_at) VALUES (?,?,?,NOW())")->execute([$siswa_id,$pid,$data]);
        }
    } catch (Exception $e) {
        // fallback
        $logStmt = $pdo->prepare("INSERT INTO log_aktivitas (id_users,aktivitas) VALUES (?,?)");
        $logStmt->execute([$pid,'Simpan kompetensi siswa #'.$siswa_id.': '.implode(',',$kompChecked)]);
    }
    $_SESSION['toast'] = ['msg'=>'Kompetensi berhasil disimpan!','type'=>'success'];
    header('Location: kompetensi.php?siswa_id='.$siswa_id); exit;
}

$selectedId = (int)($_GET['siswa_id'] ?? ($siswaList[0]['id'] ?? 0));
$selectedSiswa = null;
foreach($siswaList as $s) { if($s['id'] == $selectedId) { $selectedSiswa = $s; break; } }

// Load saved kompetensi
$savedKomp = [];
try {
    $stmt = $pdo->prepare("SELECT data_kompetensi FROM kompetensi_pkl WHERE siswa_id=? AND pembimbing_id=?");
    $stmt->execute([$selectedId,$pid]);
    $row = $stmt->fetch();
    if ($row) $savedKomp = json_decode($row['data_kompetensi'], true) ?: [];
} catch (Exception $e) { $savedKomp = []; }

$totalChecked = count($savedKomp);
$totalKomp    = count($kompetensiList);
$pct = $totalKomp > 0 ? round($totalChecked/$totalKomp*100) : 0;

include 'partials/header.php';
?>

<div class="breadcrumb"><i class="fas fa-home"></i> <i class="fas fa-chevron-right" style="font-size:.6rem"></i> <span>Penilaian Kompetensi</span></div>

<div style="display:grid;grid-template-columns:260px 1fr;gap:20px">
  <!-- LIST SISWA -->
  <div class="panel" style="height:fit-content">
    <div style="font-size:.75rem;font-weight:600;color:#64748b;text-transform:uppercase;letter-spacing:1px;margin-bottom:12px">Pilih Siswa</div>
    <?php foreach($siswaList as $s):
      $inisial = initials($s['nama_depan'], $s['nama_belakang']);
      $color   = avatarColor($s['id']);
      $isActive = $s['id'] == $selectedId;
    ?>
    <a href="kompetensi.php?siswa_id=<?=$s['id']?>" class="sidebar-item <?=$isActive?'active':''?>" style="gap:8px;padding:8px 10px;margin-bottom:4px">
      <div style="width:28px;height:28px;border-radius:50%;background:<?=$color?>22;display:flex;align-items:center;justify-content:center;font-size:.62rem;font-weight:700;color:<?=$color?>;flex-shrink:0"><?=$inisial?></div>
      <div style="font-size:.82rem;color:#f1f5f9;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($s['nama_depan'].' '.$s['nama_belakang']) ?></div>
    </a>
    <?php endforeach; ?>
  </div>

  <!-- KOMPETENSI FORM -->
  <div class="panel">
    <?php if($selectedSiswa): ?>
    <div class="panel-header">
      <h3>Kompetensi <?= htmlspecialchars($selectedSiswa['nama_depan'].' '.$selectedSiswa['nama_belakang']) ?></h3>
      <span style="font-size:.82rem;color:#4ade80;font-weight:600" id="prog-text"><?=$totalChecked?>/<?=$totalKomp?> tercapai</span>
    </div>
    <div style="margin-bottom:16px">
      <div class="progress-bar">
        <div class="progress-fill" style="background:linear-gradient(90deg,#6366f1,#4ade80);width:<?=$pct?>%" id="prog-bar"></div>
      </div>
    </div>

    <form method="POST">
      <input type="hidden" name="siswa_id" value="<?=$selectedId?>">
      <div id="komp-list">
        <?php foreach($kompetensiList as $k):
          $checked = in_array($k['id'], $savedKomp);
        ?>
        <label class="komp-item" style="cursor:pointer">
          <input type="checkbox" name="komp[]" value="<?=$k['id']?>" <?=$checked?'checked':''?> style="display:none" onchange="updateProgress()">
          <div class="komp-check <?=$checked?'checked':''?>" onclick="this.previousElementSibling.click(); this.classList.toggle('checked'); this.innerHTML = this.classList.contains('checked') ? '<i class=\'fas fa-check\' style=\'font-size:.65rem\'></i>' : ''">
            <?= $checked ? '<i class="fas fa-check" style="font-size:.65rem"></i>' : '' ?>
          </div>
          <div class="komp-label">
            <?= htmlspecialchars($k['label']) ?>
            <small><?= htmlspecialchars($k['cat']) ?></small>
          </div>
        </label>
        <?php endforeach; ?>
      </div>
      <div style="margin-top:16px;padding-top:16px;border-top:1px solid rgba(255,255,255,.06)">
        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-save"></i> Simpan Penilaian</button>
      </div>
    </form>
    <?php else: ?>
    <div class="empty-state"><i class="fas fa-tasks"></i><p>Pilih siswa untuk menilai kompetensi</p></div>
    <?php endif; ?>
  </div>
</div>

<script>
function updateProgress() {
  const total   = document.querySelectorAll('#komp-list input[type=checkbox]').length;
  const checked = document.querySelectorAll('#komp-list input[type=checkbox]:checked').length;
  document.getElementById('prog-text').textContent = checked + '/' + total + ' tercapai';
  document.getElementById('prog-bar').style.width = Math.round(checked/total*100) + '%';
}
</script>

<?php include 'partials/footer.php'; ?>
