# SIMPKL – Panel Pembimbing

## Setup

1. **Import database**
   - Buka phpMyAdmin
   - Buat database baru: `webpkl_fixed`
   - Import file `webpkl_fixed.sql`

2. **Taruh folder ini di htdocs/www**
   ```
   htdocs/simpkl/
   ```

3. **Konfigurasi database** (jika perlu)
   Edit `config.php`:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');     // sesuaikan password mysql kamu
   define('DB_NAME', 'webpkl_fixed');
   ```

4. **Buat tabel tambahan** (opsional, untuk fitur chat bimbingan)
   ```sql
   CREATE TABLE bimbingan_chat (
     id INT AUTO_INCREMENT PRIMARY KEY,
     pengirim_id INT NOT NULL,
     penerima_id INT NOT NULL,
     pesan TEXT NOT NULL,
     waktu DATETIME DEFAULT CURRENT_TIMESTAMP,
     FOREIGN KEY (pengirim_id) REFERENCES users(id),
     FOREIGN KEY (penerima_id) REFERENCES users(id)
   );

   CREATE TABLE kompetensi_pkl (
     id INT AUTO_INCREMENT PRIMARY KEY,
     siswa_id INT NOT NULL,
     pembimbing_id INT NOT NULL,
     data_kompetensi JSON,
     updated_at DATETIME,
     FOREIGN KEY (siswa_id) REFERENCES users(id),
     FOREIGN KEY (pembimbing_id) REFERENCES users(id)
   );
   ```

5. **Akses**
   ```
   http://localhost/simpkl/
   ```

## Akun Demo (dari database)
| Role        | Email                  | Password |
|-------------|------------------------|----------|
| Pembimbing  | pembimbing@smk.id      | password |

## Struktur File
```
simpkl/
├── index.php               ← redirect otomatis
├── login.php               ← halaman login
├── logout.php
├── config.php              ← koneksi DB + helpers
├── style.css               ← semua CSS (terpisah)
├── dashboard.php           ← halaman utama
├── siswa.php               ← daftar siswa bimbingan
├── penempatan.php          ← penempatan PKL
├── jurnal.php              ← validasi jurnal harian
├── absensi.php             ← monitoring absensi
├── laporan.php             ← review laporan PKL
├── bimbingan.php           ← chat bimbingan
├── nilai.php               ← input nilai PKL
├── kompetensi.php          ← penilaian kompetensi
├── partials/
│   ├── header.php          ← header + sidebar shared
│   └── footer.php          ← footer + JS shared
└── ajax/
    ├── siswa_detail.php    ← modal detail siswa
    └── penempatan_action.php ← approve/tolak pengajuan
```
