<?php
require_once 'config.php';
requireRole('pembimbing');
$activePage = 'bimbingan';
$pageTitle  = 'Bimbingan & Konsultasi';
$pid = getPembimbingId();
$pdo = getDB();
$siswaList = getSiswaBimbingan($pid);

// Handle kirim pesan
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pesan'])) {
    $siswa_id = (int)$_POST['siswa_id'];
    $pesan    = trim($_POST['pesan']);
    if ($pesan && $siswa_id) {
        $stmt = $pdo->prepare("INSERT INTO bimbingan_chat (pengirim_id, penerima_id, pesan, waktu) VALUES (?,?,?,NOW())");
        // Jika tabel belum ada, kita simpan ke log_aktivitas sebagai fallback
        try {
            $stmt->execute([$pid, $siswa_id, $pesan]);
        } catch (Exception $e) {
            // fallback: log saja
            $logStmt = $pdo->prepare("INSERT INTO log_aktivitas (id_users, aktivitas) VALUES (?,?)");
            $logStmt->execute([$pid, 'Bimbingan ke siswa #'.$siswa_id.': '.mb_substr($pesan,0,100)]);
        }
    }
    header('Location: bimbingan.php?siswa_id='.$siswa_id); exit;
}

$selectedId = (int)($_GET['siswa_id'] ?? ($siswaList[0]['id'] ?? 0));
$selectedSiswa = null;
foreach($siswaList as $s) { if($s['id'] == $selectedId) { $selectedSiswa = $s; break; } }

// Coba ambil chat history
$chatHistory = [];
try {
    $stmt = $pdo->prepare("SELECT bc.*, u.nama_depan, u.nama_belakang, u.role FROM bimbingan_chat bc JOIN users u ON u.id=bc.pengirim_id WHERE (bc.pengirim_id=? AND bc.penerima_id=?) OR (bc.pengirim_id=? AND bc.penerima_id=?) ORDER BY bc.waktu ASC LIMIT 50");
    $stmt->execute([$pid, $selectedId, $selectedId, $pid]);
    $chatHistory = $stmt->fetchAll();
} catch (Exception $e) {
    $chatHistory = [];
}

include 'partials/header.php';
?>

<div class="breadcrumb"><i class="fas fa-home"></i> <i class="fas fa-chevron-right" style="font-size:.6rem"></i> <span>Bimbingan &amp; Konsultasi</span></div>

<div style="display:grid;grid-template-columns:280px 1fr;gap:20px">
  <!-- DAFTAR SISWA -->
  <div class="panel" style="height:fit-content">
    <div style="font-size:.75rem;font-weight:600;color:#64748b;text-transform:uppercase;letter-spacing:1px;margin-bottom:12px">Siswa Bimbingan</div>
    <?php if(empty($siswaList)): ?>
    <div class="empty-state" style="padding:20px"><i class="fas fa-users"></i><p>Tidak ada siswa</p></div>
    <?php else: foreach($siswaList as $s):
      $isActive = $s['id'] == $selectedId;
      $inisial  = initials($s['nama_depan'], $s['nama_belakang']);
      $color    = avatarColor($s['id']);
      $nama     = htmlspecialchars($s['nama_depan'].' '.$s['nama_belakang']);
    ?>
    <a href="bimbingan.php?siswa_id=<?=$s['id']?>" class="sidebar-item <?=$isActive?'active':''?>" style="gap:10px;padding:10px;margin-bottom:4px">
      <div style="width:32px;height:32px;border-radius:50%;background:<?=$color?>22;display:flex;align-items:center;justify-content:center;font-size:.65rem;font-weight:700;color:<?=$color?>;flex-shrink:0"><?=$inisial?></div>
      <div>
        <div style="font-size:.82rem;color:#f1f5f9;font-weight:500"><?=$nama?></div>
        <div style="font-size:.7rem;color:#64748b"><?= htmlspecialchars($s['kelas']??'-') ?></div>
      </div>
    </a>
    <?php endforeach; endif; ?>
  </div>

  <!-- CHAT AREA -->
  <div class="panel">
    <?php if($selectedSiswa): 
      $inisial = initials($selectedSiswa['nama_depan'], $selectedSiswa['nama_belakang']);
      $color   = avatarColor($selectedSiswa['id']);
    ?>
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.06)">
      <div style="width:44px;height:44px;border-radius:50%;background:<?=$color?>22;display:flex;align-items:center;justify-content:center;font-weight:700;color:<?=$color?>"><?=$inisial?></div>
      <div>
        <div style="font-weight:600;color:#f1f5f9"><?= htmlspecialchars($selectedSiswa['nama_depan'].' '.$selectedSiswa['nama_belakang']) ?></div>
        <div style="font-size:.75rem;color:#64748b"><?= htmlspecialchars($selectedSiswa['kelas']??'-') ?> · <?= htmlspecialchars($selectedSiswa['nama_perusahaan']??'-') ?></div>
      </div>
    </div>

    <div class="chat-container" id="chat-box">
      <?php if(empty($chatHistory)): ?>
      <div style="text-align:center;padding:40px;color:#334155;font-size:.85rem"><i class="fas fa-comments" style="font-size:2rem;display:block;margin-bottom:10px;opacity:.3"></i>Belum ada percakapan. Mulai bimbingan!</div>
      <?php else: foreach($chatHistory as $c):
        $isSelf = $c['pengirim_id'] == $pid;
        $bubbleClass = $isSelf ? 'pembimbing' : 'siswa';
        $waktu = date('d M Y H:i', strtotime($c['waktu']));
      ?>
      <div style="align-self:<?=$isSelf?'flex-end':'flex-start'?>">
        <div class="chat-meta" style="text-align:<?=$isSelf?'right':'left'?>"><?= htmlspecialchars($c['nama_depan']) ?> · <?=$waktu?></div>
        <div class="chat-bubble <?=$bubbleClass?>"><?= nl2br(htmlspecialchars($c['pesan'])) ?></div>
      </div>
      <?php endforeach; endif; ?>
    </div>

    <form method="POST" style="display:flex;gap:8px">
      <input type="hidden" name="siswa_id" value="<?=$selectedSiswa['id']?>">
      <input type="text" name="pesan" class="form-control" placeholder="Tulis pesan bimbingan..." style="flex:1" required>
      <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-paper-plane"></i></button>
    </form>
    <?php else: ?>
    <div class="empty-state"><i class="fas fa-comments"></i><p>Pilih siswa untuk memulai sesi bimbingan</p></div>
    <?php endif; ?>
  </div>
</div>

<script>
// Auto-scroll chat to bottom
const chatBox = document.getElementById('chat-box');
if (chatBox) chatBox.scrollTop = chatBox.scrollHeight;
</script>

<?php include 'partials/footer.php'; ?>
