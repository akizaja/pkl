<?php
session_start();
session_destroy(); // Bersihin session lama biar ga otomatis login
session_start();
include "config.php";

$error = ""; $success = "";
if (isset($_POST['register'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $role     = mysqli_real_escape_string($conn, $_POST['role']);

    // Cek username unik
    $check = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username'");
    if (mysqli_num_rows($check) > 0) {
        $error = "Username '$username' sudah terpakai!";
    } else {
        // Simpan ke tabel users sesuai struktur simpkl_2.sql
        $query = "INSERT INTO users (username, password, role, is_deleted) VALUES ('$username', '$password', '$role', 0)";
        if (mysqli_query($conn, $query)) {
            $success = "Akun <b>$role</b> berhasil dibuat! Silakan klik link login di bawah.";
        } else {
            $error = "Gagal daftar: " . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register — SIMPKL</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        body { background: #090913; font-family: 'Poppins', sans-serif; margin: 0; color: #fff; }
        .wrapper { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: radial-gradient(circle at 85% 70%, #1c1c52 0%, #090913 100%); padding: 20px; }
        .box { width: 100%; max-width: 420px; background: rgba(255, 255, 255, 0.03); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.1); padding: 40px; border-radius: 24px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5); }
        .brand { display: flex; align-items: center; gap: 15px; margin-bottom: 30px; }
        .brand-icon { width: 45px; height: 45px; background: #fff; color: #090913; display: flex; align-items: center; justify-content: center; border-radius: 12px; font-size: 1.2rem; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-size: 0.85rem; margin-bottom: 8px; color: #94a3b8; }
        .input-wrap { position: relative; }
        .input-wrap i { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #64748b; }
        .form-control { width: 100%; background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.1); padding: 12px 15px 12px 45px; border-radius: 12px; color: #fff; font-size: 0.9rem; box-sizing: border-box; transition: 0.3s; }
        .role-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px; }
        .role-grid input { display: none; }
        .role-grid label { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); padding: 10px; border-radius: 12px; text-align: center; font-size: 0.8rem; cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: 5px; color: #94a3b8; transition: 0.2s; }
        .role-grid input:checked + label { background: #fff; color: #090913; font-weight: 600; }
        .btn { width: 100%; padding: 14px; background: #fff; color: #090913; border: none; border-radius: 12px; font-weight: 700; cursor: pointer; margin-top: 25px; transition: 0.3s; }
        .btn:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(255,255,255,0.1); }
        .msg { padding: 10px; border-radius: 10px; font-size: 0.8rem; margin-bottom: 20px; border: 1px solid; }
        .error { background: rgba(239, 68, 68, 0.1); color: #f87171; border-color: rgba(239, 68, 68, 0.2); }
        .success { background: rgba(34, 197, 94, 0.1); color: #4ade80; border-color: rgba(34, 197, 94, 0.2); }
        .footer-link { text-align: center; margin-top: 20px; font-size: 0.85rem; color: #94a3b8; }
        .footer-link a { color: #fff; font-weight: 600; text-decoration: none; }
    </style>
</head>
<body>
<div class="wrapper">
    <div class="box">
        <div class="brand">
            <div class="brand-icon"><i class="fas fa-user-plus"></i></div>
            <h1 style="margin:0; font-size:1.5rem;">DAFTAR</h1>
        </div>
        <?php if($error): ?><div class="msg error"><i class="fas fa-times-circle"></i> <?= $error ?></div><?php endif; ?>
        <?php if($success): ?><div class="msg success"><i class="fas fa-check-circle"></i> <?= $success ?></div><?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label>Username</label>
                <div class="input-wrap"><i class="fas fa-user"></i><input type="text" name="username" class="form-control" placeholder="Pilih Username" required autocomplete="off"></div>
            </div>
            <div class="form-group">
                <label>Password</label>
                <div class="input-wrap"><i class="fas fa-lock"></i><input type="password" name="password" class="form-control" placeholder="Password" required></div>
            </div>
            <div class="form-group">
                <label>Daftar Sebagai:</label>
                <div class="role-grid">
                    <input type="radio" name="role" value="siswa" id="r-siswa" checked><label for="r-siswa"><i class="fas fa-user-graduate"></i>Siswa</label>
                    <input type="radio" name="role" value="admin" id="r-admin"><label for="r-admin"><i class="fas fa-user-shield"></i>Admin</label>
                    <input type="radio" name="role" value="pembimbing" id="r-pembimbing"><label for="r-pembimbing"><i class="fas fa-chalkboard-teacher"></i>Pembimbing</label>
                    <input type="radio" name="role" value="wakasek" id="r-wakasek"><label for="r-wakasek"><i class="fas fa-user-tie"></i>Wakasek</label>
                </div>
            </div>
            <button type="submit" name="register" class="btn">DAFTAR SEKARANG</button>
        </form>
        <div class="footer-link">Sudah punya akun? <a href="login.php">Login di sini</a></div>
    </div>
</div>
</body>
</html>